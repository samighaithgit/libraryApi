import {
  Body,
  Controller,
  Post,
} from '@nestjs/common';

import { AuthService } from './auth.service';
import { RegisterDto } from './dto/register.dto';
import type { LoginDto } from './dto/login.dto';
import type { RefreshTokenDto } from './dto/refresh-token.dto';

@Controller('auth')
export class AuthController {

  constructor(
    private readonly authService: AuthService,
  ) {}

  @Post('register')
  register(
    @Body() dto: RegisterDto
  ) {

    return this.authService.register(dto);
  }


  @Post('login')
login(
  @Body() dto: LoginDto
) {

  return this.authService.login(dto);
}

@Post('refresh')
refresh(
  @Body() dto: RefreshTokenDto
) {

  return this.authService.refresh(dto);
}
}